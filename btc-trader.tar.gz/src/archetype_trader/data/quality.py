"""Data validation and the data-quality report.

Runs before anything is learned. A bad timestamp index or a crossed book
silently poisons every downstream result, so these checks are hard failures by
default and only the *reportable* conditions (gaps, flat bars) are warnings.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any

import numpy as np

from archetype_trader.data.types import MarketData


@dataclass
class DataQualityReport:
    n_bars: int
    start: str
    end: str
    bar_minutes: int
    symbol: str
    levels: int
    data_hash: str
    duplicates_removed: int = 0
    rows_reordered: bool = False
    gaps: list[dict[str, Any]] = field(default_factory=list)
    n_gap_bars_missing: int = 0
    nan_counts: dict[str, int] = field(default_factory=dict)
    flat_bars: int = 0
    zero_volume_bars: int = 0
    crossed_book_bars: int = 0
    errors: list[str] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return not self.errors

    def to_dict(self) -> dict[str, Any]:
        return asdict(self) | {"ok": self.ok}

    def write(self, path: str | Path) -> Path:
        import json

        p = Path(path)
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(json.dumps(self.to_dict(), indent=2, default=str))
        return p


def normalise_market_data(data: MarketData) -> tuple[MarketData, int, bool]:
    """Sort by timestamp and drop duplicate timestamps (keeping the last).

    Returns ``(clean, n_duplicates_removed, was_reordered)``.
    """
    ts = data.ts
    order = np.argsort(ts, kind="stable")
    reordered = not np.array_equal(order, np.arange(ts.shape[0]))
    data = _take(data, order)

    ts = data.ts
    # Keep the last record for a repeated timestamp: later snapshots of the
    # same bar are revisions, not new information.
    keep = np.ones(ts.shape[0], dtype=bool)
    if ts.shape[0] > 1:
        keep[:-1] = ts[:-1] != ts[1:]
    removed = int((~keep).sum())
    if removed:
        data = _take(data, np.flatnonzero(keep))
    return data, removed, reordered


def _take(data: MarketData, idx: np.ndarray) -> MarketData:
    from dataclasses import replace

    book: dict[str, np.ndarray | None] = {}
    for label in ("bid_px", "bid_sz", "ask_px", "ask_sz"):
        arr = getattr(data, label)
        book[label] = None if arr is None else arr[idx]
    return replace(
        data,
        ts=data.ts[idx],
        open=data.open[idx],
        high=data.high[idx],
        low=data.low[idx],
        close=data.close[idx],
        volume=data.volume[idx],
        **book,
    )


def validate_market_data(
    data: MarketData,
    *,
    max_gap_bars: int = 6,
    strict: bool = True,
) -> tuple[MarketData, DataQualityReport]:
    """Normalise then validate. Raises on structural errors when ``strict``."""
    data, dups, reordered = normalise_market_data(data)
    n = len(data)
    report = DataQualityReport(
        n_bars=n,
        start=str(data.ts[0]) if n else "",
        end=str(data.ts[-1]) if n else "",
        bar_minutes=data.bar_minutes,
        symbol=data.symbol,
        levels=data.levels,
        data_hash=data.data_hash(),
        duplicates_removed=dups,
        rows_reordered=reordered,
    )
    if n < 2:
        report.errors.append(f"need at least 2 bars, got {n}")
        if strict:
            raise ValueError(report.errors[-1])
        return data, report

    # --- timestamp grid -------------------------------------------------- #
    step_ns = np.int64(data.bar_minutes) * 60 * 1_000_000_000
    deltas = np.diff(data.ts.astype("int64"))
    if (deltas <= 0).any():
        report.errors.append("timestamps are not strictly increasing after normalisation")
    off_grid = deltas % step_ns != 0
    if off_grid.any():
        report.errors.append(
            f"{int(off_grid.sum())} timestamp deltas are not multiples of {data.bar_minutes}m"
        )
    missing = (deltas // step_ns) - 1
    gap_idx = np.flatnonzero(missing > 0)
    report.n_gap_bars_missing = int(missing[gap_idx].sum())
    for i in gap_idx:
        gap = {
            "after_index": int(i),
            "after_ts": str(data.ts[i]),
            "missing_bars": int(missing[i]),
        }
        report.gaps.append(gap)
        if missing[i] > max_gap_bars:
            report.warnings.append(
                f"gap of {int(missing[i])} bars after {gap['after_ts']} exceeds max_gap_bars"
            )

    # --- values ---------------------------------------------------------- #
    for name in ("open", "high", "low", "close", "volume"):
        arr = getattr(data, name)
        bad = int((~np.isfinite(arr)).sum())
        report.nan_counts[name] = bad
        if bad:
            report.errors.append(f"{name} has {bad} non-finite values")
    prices = np.stack([data.open, data.high, data.low, data.close])
    if (prices <= 0).any():
        report.errors.append("non-positive prices present")
    if (data.volume < 0).any():
        report.errors.append("negative volume present")
    if (data.high < data.low).any():
        report.errors.append("high < low on some bars")
    hi_ok = (data.high >= data.open - 1e-9) & (data.high >= data.close - 1e-9)
    lo_ok = (data.low <= data.open + 1e-9) & (data.low <= data.close + 1e-9)
    if not (hi_ok.all() and lo_ok.all()):
        report.errors.append("high/low do not bracket open/close on some bars")

    report.flat_bars = int((data.high == data.low).sum())
    report.zero_volume_bars = int((data.volume == 0).sum())
    if report.zero_volume_bars:
        report.warnings.append(f"{report.zero_volume_bars} zero-volume bars")

    # --- order book ------------------------------------------------------ #
    if data.has_book:
        assert data.bid_px is not None and data.ask_px is not None  # noqa: S101
        assert data.bid_sz is not None and data.ask_sz is not None  # noqa: S101
        crossed = data.bid_px[:, 0] >= data.ask_px[:, 0]
        report.crossed_book_bars = int(crossed.sum())
        if report.crossed_book_bars:
            report.errors.append(f"{report.crossed_book_bars} crossed/locked book snapshots")
        if data.levels > 1:
            if (np.diff(data.bid_px, axis=1) >= 0).any():
                report.errors.append("bid_px is not strictly decreasing across levels")
            if (np.diff(data.ask_px, axis=1) <= 0).any():
                report.errors.append("ask_px is not strictly increasing across levels")
        if (data.bid_sz < 0).any() or (data.ask_sz < 0).any():
            report.errors.append("negative book sizes present")

    if strict and report.errors:
        raise ValueError("data quality errors: " + "; ".join(report.errors))
    return data, report
