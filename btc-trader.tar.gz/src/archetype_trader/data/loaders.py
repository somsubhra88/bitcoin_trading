"""Adapters from on-disk files (and optionally a public exchange API) to
:class:`~archetype_trader.data.types.MarketData`.

Accepted tabular schema (CSV or Parquet), column names case-insensitive:

===================  =========================================================
``timestamp``        UTC bar close. Epoch ms/s integers or an ISO-8601 string.
``open`` ``high``    Bar OHLC, strictly positive floats.
``low`` ``close``
``volume``           Base-asset volume for the bar, non-negative.
``bid_px_0..L-1``    Optional L2 snapshot at the bar close, best-first.
``bid_sz_0..L-1``
``ask_px_0..L-1``
``ask_sz_0..L-1``
===================  =========================================================

No credentials are read or accepted here: only public endpoints are supported,
and the downloader is opt-in.
"""

from __future__ import annotations

import os
import re
from pathlib import Path

import numpy as np
import polars as pl

from archetype_trader.config import DataConfig
from archetype_trader.data.quality import DataQualityReport, validate_market_data
from archetype_trader.data.synthetic import generate_synthetic
from archetype_trader.data.types import MarketData
from archetype_trader.utils.logging import get_logger, log_event

logger = get_logger(__name__)

_REQUIRED = ("timestamp", "open", "high", "low", "close", "volume")
_BOOK_RE = re.compile(r"^(bid|ask)_(px|sz)_(\d+)$")


def load_market_data(
    cfg: DataConfig, *, strict: bool = True
) -> tuple[MarketData, DataQualityReport]:
    """Load, normalise and validate market data per ``cfg``."""
    if cfg.source == "synthetic":
        data = generate_synthetic(
            cfg.synthetic,
            bar_minutes=cfg.bar_minutes,
            orderbook_levels=cfg.orderbook_levels,
            symbol=cfg.symbol,
        )
    elif cfg.source in ("csv", "parquet"):
        assert cfg.path is not None  # enforced by DataConfig validation  # noqa: S101
        frame = _read_frame(cfg.path, cfg.source)
        data = market_data_from_frame(
            frame,
            symbol=cfg.symbol,
            bar_minutes=cfg.bar_minutes,
            orderbook_levels=cfg.orderbook_levels,
        )
    else:  # pragma: no cover - Literal keeps this unreachable
        raise ValueError(f"unknown data source {cfg.source!r}")

    data, report = validate_market_data(data, max_gap_bars=cfg.max_gap_bars, strict=strict)
    log_event(
        logger,
        "data.loaded",
        source=cfg.source,
        symbol=cfg.symbol,
        bars=len(data),
        levels=data.levels,
        gaps=len(report.gaps),
        data_hash=report.data_hash[:12],
    )
    return data, report


def _read_frame(path: str | Path, source: str) -> pl.DataFrame:
    p = Path(path)
    if not p.exists():
        raise FileNotFoundError(f"data file not found: {p}")
    if source == "parquet":
        return pl.read_parquet(p)
    return pl.read_csv(p, try_parse_dates=True)


def market_data_from_frame(
    frame: pl.DataFrame,
    *,
    symbol: str = "BTCUSDT",
    bar_minutes: int = 10,
    orderbook_levels: int = 0,
) -> MarketData:
    """Convert a tabular frame to :class:`MarketData`.

    ``orderbook_levels`` truncates (never pads) the book: asking for more
    levels than the file provides is an error, because silently padding with
    zeros would fabricate liquidity.
    """
    renames = {c: c.lower().strip() for c in frame.columns}
    frame = frame.rename(renames)
    missing = [c for c in _REQUIRED if c not in frame.columns]
    if missing:
        raise ValueError(f"frame is missing required columns: {missing}")

    ts = _to_datetime64(frame["timestamp"])
    ohlcv = {
        name: frame[name].cast(pl.Float64).to_numpy().astype(np.float64, copy=True)
        for name in ("open", "high", "low", "close", "volume")
    }

    book: dict[str, np.ndarray | None] = {
        "bid_px": None,
        "bid_sz": None,
        "ask_px": None,
        "ask_sz": None,
    }
    if orderbook_levels > 0:
        available = _book_levels(frame.columns)
        if available < orderbook_levels:
            raise ValueError(
                f"requested {orderbook_levels} order-book levels but the file provides {available}"
            )
        for side in ("bid", "ask"):
            for kind in ("px", "sz"):
                cols = [f"{side}_{kind}_{i}" for i in range(orderbook_levels)]
                book[f"{side}_{kind}"] = (
                    frame.select(cols).cast(pl.Float64).to_numpy().astype(np.float64, copy=True)
                )

    return MarketData(
        ts=ts,
        symbol=symbol,
        bar_minutes=bar_minutes,
        **ohlcv,
        **book,
    )


def _book_levels(columns: list[str]) -> int:
    """Number of complete L2 levels present (all four arrays required)."""
    found: dict[tuple[str, str], set[int]] = {}
    for col in columns:
        m = _BOOK_RE.match(col)
        if m:
            found.setdefault((m.group(1), m.group(2)), set()).add(int(m.group(3)))
    if len(found) < 4:
        return 0
    common = set.intersection(*found.values())
    level = 0
    while level in common:
        level += 1
    return level


def _to_datetime64(series: pl.Series) -> np.ndarray:
    """Coerce epoch ints / ISO strings / datetimes to UTC ``datetime64[ns]``."""
    if series.dtype == pl.Datetime:
        return series.cast(pl.Datetime("ns")).to_numpy().astype("datetime64[ns]")
    if series.dtype == pl.Date:
        return series.cast(pl.Datetime("ns")).to_numpy().astype("datetime64[ns]")
    if series.dtype.is_integer() or series.dtype.is_float():
        vals = series.cast(pl.Int64).to_numpy()
        # Disambiguate seconds / milliseconds / microseconds by magnitude.
        # 1e11 s is year 5138 and 1e11 ms is year 1973, so the boundary is safe
        # for any plausible crypto timestamp.
        peak = int(np.abs(vals).max()) if vals.size else 0
        if peak < 10**11:
            unit = "s"
        elif peak < 10**14:
            unit = "ms"
        elif peak < 10**17:
            unit = "us"
        else:
            unit = "ns"
        return vals.astype(f"datetime64[{unit}]").astype("datetime64[ns]")
    parsed = series.cast(pl.String).str.to_datetime(time_zone="UTC", strict=True)
    return parsed.dt.replace_time_zone(None).cast(pl.Datetime("ns")).to_numpy()


# --------------------------------------------------------------------------- #
# Optional public downloader
# --------------------------------------------------------------------------- #
def download_public_klines(
    symbol: str,
    interval: str,
    start: str,
    end: str,
    *,
    out_path: str | Path,
    base_url: str = "https://api.binance.com",
    limit: int = 1000,
    timeout: float = 20.0,
    ca_bundle: str | Path | None = None,
) -> Path:
    """Download public spot klines to Parquet. No API key is used or accepted.

    Public market data only; this deliberately cannot place orders. Timestamps
    are written as the bar **close** so they match the loader's convention.
    """
    import httpx

    start_ms = int(np.datetime64(start.replace("Z", ""), "ms").astype("int64"))
    end_ms = int(np.datetime64(end.replace("Z", ""), "ms").astype("int64"))
    rows: list[dict[str, float | int]] = []
    cursor = start_ms
    # Honour an explicitly supplied corporate/system CA without ever disabling
    # certificate verification. Environment variables keep the CLI convenient
    # for standard SSL tooling while ``ca_bundle`` remains deterministic.
    if ca_bundle is not None:
        verify: str | bool = str(ca_bundle)
    else:
        verify = os.environ.get("SSL_CERT_FILE") or os.environ.get("REQUESTS_CA_BUNDLE") or True
    with httpx.Client(timeout=timeout, base_url=base_url, verify=verify) as client:
        while cursor < end_ms:
            resp = client.get(
                "/api/v3/klines",
                params={
                    "symbol": symbol,
                    "interval": interval,
                    "startTime": cursor,
                    "endTime": end_ms,
                    "limit": limit,
                },
            )
            resp.raise_for_status()
            batch = resp.json()
            if not batch:
                break
            for k in batch:
                rows.append(
                    {
                        # k[6] is the kline close time (ms) — the first instant
                        # at which the bar is fully observable.
                        "timestamp": int(k[6]) + 1,
                        "open": float(k[1]),
                        "high": float(k[2]),
                        "low": float(k[3]),
                        "close": float(k[4]),
                        "volume": float(k[5]),
                    }
                )
            next_cursor = int(batch[-1][0]) + 1
            if next_cursor <= cursor:
                break
            cursor = next_cursor
            log_event(logger, "download.progress", rows=len(rows), cursor=cursor)

    if not rows:
        raise RuntimeError(f"no klines returned for {symbol} {interval} {start}..{end}")
    frame = pl.DataFrame(rows).unique(subset=["timestamp"], keep="last").sort("timestamp")
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    frame.write_parquet(out)
    log_event(logger, "download.complete", path=str(out), rows=frame.height)
    return out
