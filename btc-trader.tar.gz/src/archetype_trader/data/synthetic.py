"""Synthetic BTC-like market generator.

Exists so the whole pipeline (including the fast smoke config and the test
suite) runs with no network access and no data licence. The process is a
two-state stochastic-volatility GBM with an AR(1) drift, which produces
regime structure a trend policy can plausibly exploit — enough to exercise
every code path without pretending to be real BTC.
"""

from __future__ import annotations

import numpy as np

from archetype_trader.config import SyntheticConfig
from archetype_trader.data.types import MarketData


def generate_synthetic(
    cfg: SyntheticConfig,
    *,
    bar_minutes: int = 10,
    orderbook_levels: int = 0,
    symbol: str = "BTCUSDT",
) -> MarketData:
    """Generate ``cfg.n_bars`` bars, optionally with an L2 book."""
    rng = np.random.default_rng(cfg.seed)
    n = cfg.n_bars

    # Sticky two-state volatility regime.
    switch = rng.random(n) > cfg.regime_persistence
    regime = np.zeros(n, dtype=np.int8)
    state = 0
    for i in range(n):
        if switch[i]:
            state = 1 - state
        regime[i] = state
    vol = np.where(regime == 1, cfg.vol_high, cfg.vol_low)

    # AR(1) drift shared across the bar so trends persist for many bars.
    drift = np.zeros(n, dtype=np.float64)
    shocks = rng.normal(0.0, cfg.drift_scale, size=n)
    for i in range(1, n):
        drift[i] = cfg.drift_ar * drift[i - 1] + shocks[i]

    log_ret = drift + vol * rng.standard_normal(n)
    log_ret[0] = 0.0
    close = cfg.initial_price * np.exp(np.cumsum(log_ret))

    # Open = previous close with a small overnight-style gap; high/low bracket
    # both ends so OHLC stays internally consistent.
    gap = vol * 0.25 * rng.standard_normal(n)
    open_ = np.empty(n, dtype=np.float64)
    open_[0] = cfg.initial_price
    open_[1:] = close[:-1] * np.exp(gap[1:])
    body_hi = np.maximum(open_, close)
    body_lo = np.minimum(open_, close)
    wick = np.abs(vol * rng.standard_normal(n)) * close
    high = body_hi + wick
    low = np.maximum(body_lo - wick, 1e-8)

    # Volume rises with volatility (typical of crypto) plus lognormal noise.
    # Calibrated to a BTC-like ~200-600 base units per 10-minute bar, so that a
    # $100k book trades at a realistic (small) participation rate.
    volume = np.exp(rng.normal(0.0, 0.4, size=n)) * (200.0 + 50_000.0 * vol)

    data = MarketData(
        ts=_bar_index(cfg.start, n, bar_minutes),
        open=open_,
        high=high,
        low=low,
        close=close,
        volume=volume,
        symbol=symbol,
        bar_minutes=bar_minutes,
    )
    if orderbook_levels <= 0:
        return data
    return _attach_book(data, cfg, regime, rng, orderbook_levels)


def _bar_index(start: str, n: int, bar_minutes: int) -> np.ndarray:
    t0 = np.datetime64(start.replace("Z", ""), "ns")
    step = np.timedelta64(bar_minutes * 60, "s").astype("timedelta64[ns]")
    return t0 + np.arange(n, dtype="int64") * step


def _attach_book(
    data: MarketData,
    cfg: SyntheticConfig,
    regime: np.ndarray,
    rng: np.random.Generator,
    levels: int,
) -> MarketData:
    """Build a plausible L2 book around each bar close.

    Spread widens in the high-vol regime; depth decays geometrically away from
    the touch and is skewed by a persistent imbalance signal so order-flow
    features are not pure noise.
    """
    n = len(data)
    mid = data.close
    spread_bps = np.where(regime == 1, cfg.spread_bps_high, cfg.spread_bps_low)
    spread_bps = spread_bps * np.exp(rng.normal(0.0, 0.2, size=n))
    half = mid * spread_bps * 1e-4 * 0.5
    tick = np.maximum(mid * 1e-5, 0.01)

    offsets = np.arange(levels, dtype=np.float64)[None, :]
    bid_px = (mid - half)[:, None] - offsets * tick[:, None]
    ask_px = (mid + half)[:, None] + offsets * tick[:, None]

    # Persistent imbalance in (-1, 1): AR(1) so OFI has autocorrelation.
    imb = np.zeros(n, dtype=np.float64)
    eps = rng.normal(0.0, 0.3, size=n)
    for i in range(1, n):
        imb[i] = 0.9 * imb[i - 1] + eps[i]
    imb = np.tanh(imb)

    base = (data.volume / max(levels, 1))[:, None] * np.exp(-0.15 * offsets)
    noise_b = np.exp(rng.normal(0.0, 0.25, size=(n, levels)))
    noise_a = np.exp(rng.normal(0.0, 0.25, size=(n, levels)))
    bid_sz = np.maximum(base * (1.0 + imb[:, None]) * noise_b, 1e-6)
    ask_sz = np.maximum(base * (1.0 - imb[:, None]) * noise_a, 1e-6)

    return MarketData(
        ts=data.ts,
        open=data.open,
        high=data.high,
        low=data.low,
        close=data.close,
        volume=data.volume,
        bid_px=bid_px,
        bid_sz=bid_sz,
        ask_px=ask_px,
        ask_sz=ask_sz,
        symbol=data.symbol,
        bar_minutes=data.bar_minutes,
    )
