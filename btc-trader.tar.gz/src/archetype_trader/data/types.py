"""In-memory market-data container.

Columnar NumPy rather than a DataFrame: every downstream consumer (features,
planner, environment) is array maths, and keeping raw arrays avoids repeated
DataFrame -> ndarray conversions on the hot path. Polars is used only at the IO
boundary.

Timestamps are UTC ``datetime64[ns]`` and label the **close** of each bar, so a
row is fully observable at its own timestamp and never before.
"""

from __future__ import annotations

from dataclasses import dataclass, replace

import numpy as np

_OHLCV = ("open", "high", "low", "close", "volume")


@dataclass(frozen=True)
class MarketData:
    """OHLCV bars plus optional L2 snapshots aligned to the same bar closes.

    Order-book arrays are shaped ``(T, levels)`` and ordered best-first, i.e.
    ``bid_px[:, 0]`` is the best bid and ``ask_px[:, 0]`` the best ask.
    """

    ts: np.ndarray
    open: np.ndarray
    high: np.ndarray
    low: np.ndarray
    close: np.ndarray
    volume: np.ndarray
    bid_px: np.ndarray | None = None
    bid_sz: np.ndarray | None = None
    ask_px: np.ndarray | None = None
    ask_sz: np.ndarray | None = None
    symbol: str = "BTCUSDT"
    bar_minutes: int = 10

    def __post_init__(self) -> None:
        n = self.ts.shape[0]
        if self.ts.dtype != np.dtype("datetime64[ns]"):
            raise TypeError(f"ts must be datetime64[ns], got {self.ts.dtype}")
        for name in _OHLCV:
            arr = getattr(self, name)
            if arr.shape != (n,):
                raise ValueError(f"{name} has shape {arr.shape}, expected {(n,)}")
            if arr.dtype != np.float64:
                raise TypeError(f"{name} must be float64, got {arr.dtype}")
        book = self.book_arrays()
        if book:
            levels = book[0].shape[1]
            for label, arr in zip(("bid_px", "bid_sz", "ask_px", "ask_sz"), book, strict=True):
                if arr.shape != (n, levels):
                    raise ValueError(f"{label} has shape {arr.shape}, expected {(n, levels)}")

    # -- shape helpers ----------------------------------------------------- #
    def __len__(self) -> int:
        return int(self.ts.shape[0])

    @property
    def has_book(self) -> bool:
        return self.bid_px is not None

    @property
    def levels(self) -> int:
        return 0 if self.bid_px is None else int(self.bid_px.shape[1])

    def book_arrays(self) -> tuple[np.ndarray, ...]:
        """The four book arrays, or ``()`` when no book is present.

        Raises if only some of them were supplied — a half-populated book is a
        bug that would otherwise surface much later as a shape error.
        """
        parts = (self.bid_px, self.bid_sz, self.ask_px, self.ask_sz)
        present = [p is not None for p in parts]
        if not any(present):
            return ()
        if not all(present):
            raise ValueError("bid_px/bid_sz/ask_px/ask_sz must all be provided together")
        return tuple(p for p in parts if p is not None)

    # -- slicing ----------------------------------------------------------- #
    def slice(self, start: int, stop: int) -> MarketData:
        """Contiguous row slice, preserving book alignment."""
        n = len(self)
        if not 0 <= start < stop <= n:
            raise IndexError(f"invalid slice [{start}:{stop}) for {n} bars")
        sl = slice(start, stop)
        book: dict[str, np.ndarray | None] = {}
        for label in ("bid_px", "bid_sz", "ask_px", "ask_sz"):
            arr = getattr(self, label)
            book[label] = None if arr is None else arr[sl]
        return replace(
            self,
            ts=self.ts[sl],
            open=self.open[sl],
            high=self.high[sl],
            low=self.low[sl],
            close=self.close[sl],
            volume=self.volume[sl],
            **book,
        )

    # -- derived quantities ------------------------------------------------ #
    def mid(self) -> np.ndarray:
        """Best bid/ask mid when a book exists, else the bar close."""
        if self.bid_px is not None and self.ask_px is not None:
            return 0.5 * (self.bid_px[:, 0] + self.ask_px[:, 0])
        return self.close.copy()

    def half_spread_frac(self, fallback_bps: float) -> np.ndarray:
        """Half-spread as a fraction of mid, per bar."""
        if self.bid_px is not None and self.ask_px is not None:
            mid = self.mid()
            return 0.5 * (self.ask_px[:, 0] - self.bid_px[:, 0]) / np.maximum(mid, 1e-12)
        return np.full(len(self), fallback_bps * 1e-4, dtype=np.float64)

    def log_returns(self) -> np.ndarray:
        """Close-to-close log returns; element 0 is 0.0 (no prior bar)."""
        out = np.zeros(len(self), dtype=np.float64)
        if len(self) > 1:
            out[1:] = np.diff(np.log(self.close))
        return out

    def data_hash(self) -> str:
        from archetype_trader.utils.provenance import sha256_array

        arrays = [self.ts.astype("int64"), self.open, self.high, self.low, self.close, self.volume]
        arrays.extend(self.book_arrays())
        return sha256_array(*arrays)
