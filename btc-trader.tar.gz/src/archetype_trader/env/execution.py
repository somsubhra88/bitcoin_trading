"""Execution simulator: next-bar fills with spread, slippage, latency and caps.

Timing contract (the single most important thing in this file):

* A decision is made on the **close of bar** ``t`` using data up to ``t``.
* It is queued and executed at the **open of bar** ``t + latency_bars``, with
  ``latency_bars >= 1`` enforced by the config schema.
* The reference mark at execution is that open price. Anything the fill pays
  above/below it is booked as execution cost.

Rejections and partial fills are first-class results rather than exceptions, so
the environment can log intervention rates and the tests can assert that an
impossible fill never happens.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import StrEnum

import numpy as np

from archetype_trader.config import CostConfig
from archetype_trader.data.types import MarketData


class FillStatus(StrEnum):
    NO_TRADE = "no_trade"
    FILLED = "filled"
    PARTIAL = "partial"
    REJECTED_MIN_SIZE = "rejected_min_size"
    REJECTED_STALE = "rejected_stale"
    REJECTED_NO_LIQUIDITY = "rejected_no_liquidity"


@dataclass(frozen=True)
class ExecutionResult:
    """Outcome of one execution attempt."""

    status: FillStatus
    requested_qty: float
    filled_qty: float
    exec_price: float
    mark_price: float
    fee: float
    slippage_bps: float
    half_spread_bps: float
    participation: float

    @property
    def is_rejected(self) -> bool:
        return self.status.startswith("rejected")

    @property
    def notional(self) -> float:
        return abs(self.filled_qty) * self.exec_price


class ExecutionSimulator:
    """Costed, capacity-aware fill model for a single instrument.

    Pre-computes the per-bar quantities it needs (half-spread, funding schedule)
    so ``execute`` is pure arithmetic on scalars.
    """

    def __init__(self, data: MarketData, cfg: CostConfig, *, mode: str = "spot") -> None:
        self.data = data
        self.cfg = cfg
        self.mode = mode
        self.half_spread = data.half_spread_frac(cfg.fallback_half_spread_bps)
        self.blended_fee_rate = (
            cfg.maker_fill_ratio * cfg.maker_fee_bps
            + (1.0 - cfg.maker_fill_ratio) * cfg.taker_fee_bps
        ) * 1e-4
        # Funding per event, derived from the 8h rate and the actual interval so
        # changing ``funding_interval_bars`` does not silently change the cost.
        interval_minutes = cfg.funding_interval_bars * data.bar_minutes
        self.funding_rate_per_event = cfg.funding_bps_per_8h * 1e-4 * (interval_minutes / 480.0)
        self._step_ns = np.int64(data.bar_minutes) * 60 * 1_000_000_000

        # Impact volatility, lagged by one bar so a fill at open[i] is priced
        # using only information available at close[i-1].
        from archetype_trader.features import rolling as rr

        vol = rr.rolling_std(data.log_returns(), cfg.slippage_vol_window)
        self.impact_vol = np.nan_to_num(rr.shift(vol, 1), nan=0.0)

    # -- staleness --------------------------------------------------------- #
    def is_stale(self, index: int) -> bool:
        """True when bar ``index`` is further than ``stale_after_bars`` from ``index-1``.

        A data gap means the last observation is old, so an order placed on it
        would be trading on stale information.
        """
        if index <= 0:
            return False
        gap = int(self.data.ts[index].astype("int64") - self.data.ts[index - 1].astype("int64"))
        return gap > int(self._step_ns) * self.cfg.stale_after_bars

    def funding_due(self, index: int) -> bool:
        return self.mode == "perp" and index > 0 and index % self.cfg.funding_interval_bars == 0

    # -- fills ------------------------------------------------------------- #
    def execute(self, *, index: int, requested_qty: float) -> ExecutionResult:
        """Attempt to trade ``requested_qty`` base units at the open of ``index``.

        ``index`` is the bar whose **open** is the execution price, i.e. the
        decision was made at the close of ``index - latency_bars``.
        """
        mark = float(self.data.open[index])
        hs_bps = float(self.half_spread[index] * 1e4)
        if requested_qty == 0.0:
            return ExecutionResult(
                status=FillStatus.NO_TRADE,
                requested_qty=0.0,
                filled_qty=0.0,
                exec_price=mark,
                mark_price=mark,
                fee=0.0,
                slippage_bps=0.0,
                half_spread_bps=hs_bps,
                participation=0.0,
            )

        def reject(status: FillStatus) -> ExecutionResult:
            return ExecutionResult(
                status=status,
                requested_qty=requested_qty,
                filled_qty=0.0,
                exec_price=mark,
                mark_price=mark,
                fee=0.0,
                slippage_bps=0.0,
                half_spread_bps=hs_bps,
                participation=0.0,
            )

        if self.is_stale(index):
            return reject(FillStatus.REJECTED_STALE)

        notional = abs(requested_qty) * mark
        if abs(requested_qty) < self.cfg.min_qty or notional < self.cfg.min_notional:
            return reject(FillStatus.REJECTED_MIN_SIZE)

        # Participation cap -> partial fill. The unfilled remainder is *not*
        # carried as a resting order; the target position persists, so the next
        # bar naturally retries. That is the conservative assumption.
        bar_volume = float(self.data.volume[index])
        cap = self.cfg.max_participation * bar_volume
        if cap <= 0.0:
            return reject(FillStatus.REJECTED_NO_LIQUIDITY)
        filled = float(np.sign(requested_qty) * min(abs(requested_qty), cap))
        status = (
            FillStatus.FILLED if abs(filled) >= abs(requested_qty) - 1e-15 else FillStatus.PARTIAL
        )

        book_price: float | None = None
        if self.cfg.walk_order_book and self.data.has_book:
            book_price, book_filled = self._walk_book(index, filled)
            if book_filled == 0.0:
                return reject(FillStatus.REJECTED_NO_LIQUIDITY)
            if abs(book_filled) < abs(filled) - 1e-15:
                status = FillStatus.PARTIAL
                filled = book_filled

        participation = abs(filled) / max(bar_volume, 1e-12)
        slip_bps = self._impact_bps(next_index=index, participation=participation)
        side = 1.0 if filled > 0 else -1.0

        if book_price is not None:
            # The walked book already contains the spread; add impact only.
            exec_price = book_price * (1.0 + side * slip_bps * 1e-4)
        else:
            exec_price = mark * (1.0 + side * (hs_bps + slip_bps) * 1e-4)

        fee = abs(filled) * exec_price * self.blended_fee_rate
        return ExecutionResult(
            status=status,
            requested_qty=requested_qty,
            filled_qty=filled,
            exec_price=float(exec_price),
            mark_price=mark,
            fee=float(fee),
            slippage_bps=float(slip_bps),
            half_spread_bps=hs_bps,
            participation=float(participation),
        )

    def execute_within_cash(
        self, *, index: int, requested_qty: float, cash: float
    ) -> ExecutionResult:
        """Execute, shrinking a buy that the quote balance cannot fund.

        The affordability estimate in :meth:`requested_delta` uses the mid plus a
        cost estimate, which underprices an order that walks several book levels.
        Rather than pad it with a fudge factor, price the order through the real
        fill model and, if it overdraws, rescale by the exact shortfall ratio and
        re-price. Fill cost is weakly increasing in size, so a single rescale is
        guaranteed to fit — this loop cannot iterate more than once.
        """
        result = self.execute(index=index, requested_qty=requested_qty)
        if result.filled_qty <= 0.0:
            return result
        cost = result.filled_qty * result.exec_price + result.fee
        if cost <= cash:
            return result
        if cash <= 0.0:
            return ExecutionResult(
                status=FillStatus.REJECTED_MIN_SIZE,
                requested_qty=requested_qty,
                filled_qty=0.0,
                exec_price=result.mark_price,
                mark_price=result.mark_price,
                fee=0.0,
                slippage_bps=0.0,
                half_spread_bps=result.half_spread_bps,
                participation=0.0,
            )
        # 1 - 1e-9 keeps the balance strictly non-negative under float rounding.
        scale = (cash * (1.0 - 1e-9)) / cost
        return self.execute(index=index, requested_qty=requested_qty * scale)

    def _impact_bps(self, *, next_index: int, participation: float) -> float:
        """Square-root impact in bps: ``coef * sigma_bar * sqrt(participation)``.

        Volatility-scaled so the same participation costs more in a violent
        regime, which is what the empirical square-root law says.
        """
        sigma = float(self.impact_vol[next_index])
        bps = self.cfg.slippage_coef * sigma * math.sqrt(min(participation, 1.0)) * 1e4
        return float(max(bps, self.cfg.slippage_floor_bps))

    def _walk_book(self, index: int, qty: float) -> tuple[float, float]:
        """Volume-weighted price from consuming the book. Returns ``(vwap, filled)``.

        Buys walk the ask side, sells the bid side. When the visible book cannot
        cover ``qty`` we fill only what is there — never an invented price.
        """
        if qty > 0:
            px, sz = self.data.ask_px, self.data.ask_sz
        else:
            px, sz = self.data.bid_px, self.data.bid_sz
        assert px is not None and sz is not None  # noqa: S101
        level_px = px[index]
        level_sz = sz[index]
        remaining = abs(qty)
        cost = 0.0
        taken = 0.0
        for p, s in zip(level_px, level_sz, strict=True):
            if remaining <= 0:
                break
            take = min(remaining, float(s))
            cost += take * float(p)
            taken += take
            remaining -= take
        if taken <= 0:
            return 0.0, 0.0
        return cost / taken, float(np.sign(qty) * taken)

    # -- sizing ------------------------------------------------------------ #
    def target_qty(self, *, target_position: float, equity: float, mark: float) -> float:
        """Base quantity that realises ``target_position`` (exposure/equity).

        Uses the *current* equity and mark, both known at decision time.
        """
        if mark <= 0:
            raise ValueError(f"mark must be positive, got {mark}")
        return target_position * equity / mark

    def requested_delta(
        self,
        *,
        index: int,
        target_position: float,
        equity: float,
        cash: float,
        current_qty: float,
        mark: float,
        allow_negative_cash: bool,
    ) -> float:
        """Quantity to request this bar, capped by available funding.

        A spot target of 1.0 is not literally reachable: buying ``equity / mark``
        units costs that plus spread, impact and fees, which would overdraw the
        quote balance. Rather than pretend, the buy is capped at what the cash
        balance can fund including estimated costs; the target persists, so the
        position converges to the cap over subsequent bars.

        Perpetuals borrow by construction, so no cap applies there — leverage is
        bounded by the risk shield instead.
        """
        delta = self.target_qty(target_position=target_position, equity=equity, mark=mark) - (
            current_qty
        )
        if allow_negative_cash or delta <= 0.0:
            return delta
        bar_volume = float(self.data.volume[index]) if index < self.data.volume.shape[0] else 0.0
        participation = abs(delta) / max(bar_volume, 1e-12)
        cost_frac = (
            float(self.half_spread[index])
            + self.blended_fee_rate
            + self._impact_bps(next_index=index, participation=participation) * 1e-4
        )
        affordable = max(0.0, cash) / (mark * (1.0 + cost_frac))
        return min(delta, affordable)

    def estimate_slippage_bps(self, *, index: int, qty: float) -> float:
        """Pre-trade cost estimate (half-spread + impact) for the risk shield."""
        if qty == 0.0:
            return 0.0
        bar_volume = float(self.data.volume[index])
        participation = abs(qty) / max(bar_volume, 1e-12)
        impact = self._impact_bps(next_index=index, participation=participation)
        return float(self.half_spread[index] * 1e4 + impact)
