"""Gymnasium trading environment.

Action space is a **target position**, not a buy/sell instruction: the agent
states where it wants to be and the execution simulator works out the delta,
which keeps the policy independent of current inventory and sizing.

Step semantics (``t`` = index of the last fully observed bar)::

    obs_t            features from bars <= t, plus portfolio state at close t
    step(a_t)        a_t is the target position for the coming interval
      shield         a_t -> executed target (observable state only)
      queue          target enters a latency queue of length latency_bars
      advance        t -> t + 1
      execute        the target dequeued this bar fills at open[t+1]
      mark           inventory re-marked at close[t+1]
      funding        charged on perp positions at funding boundaries
      reward         log(E_{t+1}/E_t) minus penalties
    obs_{t+1}

Nothing in this file indexes past the current bar. The environment holds the
full price arrays (it must, to advance), so the leakage tests assert on the
observation, not on the absence of the array.
"""

from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from typing import Any, ClassVar

import gymnasium as gym
import numpy as np
from gymnasium import spaces

from archetype_trader.config import EnvConfig, ShieldConfig
from archetype_trader.data.types import MarketData
from archetype_trader.env.execution import ExecutionSimulator, FillStatus
from archetype_trader.env.ledger import Ledger
from archetype_trader.env.reward import compute_reward
from archetype_trader.features.pipeline import FeatureMatrix, FeatureScaler
from archetype_trader.features.portfolio import N_PORTFOLIO_FEATURES, portfolio_features
from archetype_trader.risk.shield import RiskShield, ShieldState

_EPS = 1e-12


@dataclass
class EpisodeStats:
    """Per-episode accumulators exposed through ``info`` and ``episode_summary``."""

    net_log_returns: list[float]
    equity_curve: list[float]
    positions: list[float]
    proposed_positions: list[float]
    rewards: list[float]
    fees: float = 0.0
    funding: float = 0.0
    execution_cost: float = 0.0
    turnover_notional: float = 0.0
    n_trades: int = 0
    n_partial_fills: int = 0
    n_rejected: int = 0
    n_liquidations: int = 0
    bankrupt: bool = False


class TradingEnv(gym.Env[dict[str, np.ndarray], np.int64]):
    """Single-instrument, discrete-target-position trading environment."""

    metadata: ClassVar[dict[str, list[str]]] = {"render_modes": []}

    def __init__(
        self,
        data: MarketData,
        features: FeatureMatrix,
        scaler: FeatureScaler,
        cfg: EnvConfig,
        shield_cfg: ShieldConfig,
        *,
        start_index: int,
        end_index: int,
        bars_per_year: int = 52_560,
        horizon_hint: int | None = None,
        reconcile_every_step: bool = True,
    ) -> None:
        super().__init__()
        if start_index < max(features.valid_from, features.lookback - 1):
            raise ValueError(
                f"start_index={start_index} is inside the feature warm-up region "
                f"(valid_from={features.valid_from}, lookback={features.lookback})"
            )
        if end_index <= start_index or end_index > len(data):
            raise ValueError(f"invalid episode range [{start_index}:{end_index})")

        self.data = data
        self.features = features
        self.scaler = scaler
        self.cfg = cfg
        self.start_index = start_index
        self.end_index = end_index
        self.bars_per_year = bars_per_year
        self.horizon_hint = horizon_hint or cfg.max_episode_bars
        self.reconcile_every_step = reconcile_every_step

        self.positions: tuple[float, ...] = cfg.positions
        self.sim = ExecutionSimulator(data, cfg.costs, mode=cfg.mode)
        self.shield = RiskShield(
            shield_cfg,
            mode=cfg.mode,
            bars_per_year=bars_per_year,
            maintenance_margin=cfg.maintenance_margin,
        )

        self.action_space = spaces.Discrete(len(self.positions))
        self.observation_space = spaces.Dict(
            {
                "market": spaces.Box(
                    low=-np.inf,
                    high=np.inf,
                    shape=(features.lookback, features.n_features),
                    dtype=np.float32,
                ),
                "portfolio": spaces.Box(
                    low=-np.inf, high=np.inf, shape=(N_PORTFOLIO_FEATURES,), dtype=np.float32
                ),
            }
        )

        # Precomputed causal series used by the shield and reward.
        log_ret = data.log_returns()
        from archetype_trader.features import rolling as rr

        self._realized_vol = np.nan_to_num(
            rr.rolling_std(log_ret, shield_cfg.vol_lookback), nan=0.0
        )
        self._spread_bps = data.half_spread_frac(cfg.costs.fallback_half_spread_bps) * 2e4
        self._day_index = (data.ts.astype("datetime64[D]").astype("int64")).astype(np.int64)

        self.ledger: Ledger
        self.shield_state: ShieldState
        self.stats: EpisodeStats
        self._t = start_index
        # Bar the current episode was reset at. ``start_index`` is the earliest
        # *admissible* bar; a random reset inside the segment must be timed from
        # where it actually began, or ``max_episode_bars`` would silently
        # truncate late starts after a single step.
        self._episode_start = start_index
        self._pending: deque[float] = deque()
        self._target_position = 0.0
        self._holding_bars = 0
        self._last_step_return = 0.0
        self._turnover_window: deque[float] = deque(maxlen=cfg.costs.funding_interval_bars)
        self._terminated = False

    # -- gym API ----------------------------------------------------------- #
    def reset(
        self, *, seed: int | None = None, options: dict[str, Any] | None = None
    ) -> tuple[dict[str, np.ndarray], dict[str, Any]]:
        super().reset(seed=seed)
        start = int((options or {}).get("start_index", self.start_index))
        if start < self.start_index or start >= self.end_index:
            raise ValueError(
                f"reset start_index={start} outside [{self.start_index}:{self.end_index})"
            )
        self._t = start
        self._episode_start = start
        self.ledger = Ledger(
            initial_cash=self.cfg.initial_cash,
            allow_negative_cash=self.cfg.mode == "perp",
        )
        self.ledger.initialise_mark(float(self.data.close[self._t]))
        self.shield_state = self.shield.reset(self.cfg.initial_cash)
        self.stats = EpisodeStats(
            net_log_returns=[],
            equity_curve=[self.ledger.equity],
            positions=[0.0],
            proposed_positions=[0.0],
            rewards=[],
        )
        # Latency queue is pre-filled with "stay flat" so the first fill can only
        # happen ``latency_bars`` after the first decision.
        self._pending = deque([0.0] * (self.cfg.costs.latency_bars - 1))
        self._target_position = 0.0
        self._holding_bars = 0
        self._last_step_return = 0.0
        self._turnover_window.clear()
        self._terminated = False
        return self._observation(), self._info_base()

    def step(
        self, action: np.int64 | int
    ) -> tuple[dict[str, np.ndarray], float, bool, bool, dict[str, Any]]:
        if self._terminated:
            raise RuntimeError("step() called on a terminated episode; call reset() first")
        idx = int(action)
        if not 0 <= idx < len(self.positions):
            raise ValueError(f"action {idx} outside [0, {len(self.positions)})")
        proposed = self.positions[idx]

        # --- shield (observable state only) -------------------------------- #
        t = self._t
        current = self.ledger.position_frac
        desired_qty = self.sim.target_qty(
            target_position=proposed, equity=self.ledger.equity, mark=self.ledger.mark
        )
        est_slip = self.sim.estimate_slippage_bps(index=t, qty=desired_qty - self.ledger.qty)
        decision = self.shield.apply(
            self.shield_state,
            proposed_position=proposed,
            current_position=current,
            equity=self.ledger.equity,
            drawdown=self.ledger.drawdown,
            realized_vol_per_bar=float(self._realized_vol[t]),
            spread_bps=float(self._spread_bps[t]),
            bar_volume=float(self.data.volume[t]),
            est_slippage_bps=est_slip,
            is_stale=self.sim.is_stale(t),
            day_index=int(self._day_index[t]),
            last_step_return=self._last_step_return,
            max_positions=self.positions,
        )

        self._pending.append(decision.executed_position)
        executable = self._pending.popleft() if self._pending else decision.executed_position

        # --- advance one bar ----------------------------------------------- #
        next_t = t + 1
        equity_before = self.ledger.equity
        # Mark to the execution reference (next open) while still holding the
        # old inventory: this is holding PnL, not execution cost.
        self.ledger.set_mark(float(self.data.open[next_t]))

        delta = self.sim.requested_delta(
            index=next_t,
            target_position=executable,
            equity=self.ledger.equity,
            cash=self.ledger.cash,
            current_qty=self.ledger.qty,
            mark=self.ledger.mark,
            allow_negative_cash=self.cfg.mode == "perp",
        )
        if self.cfg.mode == "perp":
            result = self.sim.execute(index=next_t, requested_qty=delta)
        else:
            result = self.sim.execute_within_cash(
                index=next_t, requested_qty=delta, cash=self.ledger.cash
            )
        if result.filled_qty != 0.0:
            self.ledger.apply_trade(result.filled_qty, result.exec_price, result.fee)
        if result.status is FillStatus.PARTIAL:
            self.stats.n_partial_fills += 1
        if result.is_rejected:
            self.stats.n_rejected += 1

        self.ledger.set_mark(float(self.data.close[next_t]))
        funding_cost = 0.0
        if self.sim.funding_due(next_t):
            funding_cost = self.ledger.apply_funding(self.sim.funding_rate_per_event)

        # --- liquidation / bankruptcy -------------------------------------- #
        liquidated = False
        if self.cfg.mode == "perp" and self.ledger.qty != 0.0:
            maintenance = self.cfg.maintenance_margin * self.ledger.notional
            if self.ledger.equity <= maintenance:
                liquidated = True
                self._force_flatten(next_t)
                self.stats.n_liquidations += 1
        bankrupt = self.ledger.equity <= 0.0

        # --- reward --------------------------------------------------------- #
        turnover_frac = abs(result.filled_qty) * result.exec_price / max(equity_before, _EPS)
        self._turnover_window.append(turnover_frac)
        breakdown = compute_reward(
            self.cfg.reward,
            equity_before=equity_before,
            equity_after=self.ledger.equity,
            turnover_frac=turnover_frac,
            drawdown=self.ledger.drawdown,
            position_frac=self.ledger.position_frac,
            realized_vol_per_bar=float(self._realized_vol[next_t]),
            bars_per_year=self.bars_per_year,
        )

        # --- bookkeeping ---------------------------------------------------- #
        self._t = next_t
        self.ledger.step = next_t - self._episode_start
        self._last_step_return = breakdown.net_log_return
        if abs(executable) > _EPS and abs(executable - self._target_position) < _EPS:
            self._holding_bars += 1
        else:
            self._holding_bars = 0 if abs(executable) <= _EPS else 1
        self._target_position = executable

        self.stats.net_log_returns.append(breakdown.net_log_return)
        self.stats.equity_curve.append(self.ledger.equity)
        self.stats.positions.append(self.ledger.position_frac)
        self.stats.proposed_positions.append(proposed)
        self.stats.rewards.append(breakdown.reward)
        self.stats.fees = self.ledger.cum_fees
        self.stats.funding = self.ledger.cum_funding
        self.stats.execution_cost = self.ledger.cum_execution_cost
        self.stats.turnover_notional = self.ledger.cum_turnover_notional
        self.stats.n_trades = self.ledger.n_trades
        self.stats.bankrupt = bankrupt

        if self.reconcile_every_step:
            self.ledger.reconcile()

        elapsed = next_t - self._episode_start
        truncated = next_t >= self.end_index - 1 or elapsed >= self.cfg.max_episode_bars
        terminated = bool(bankrupt or liquidated)
        self._terminated = terminated or truncated

        info = self._info_base()
        info.update(
            {
                "proposed_position": proposed,
                "shielded_position": decision.executed_position,
                "executed_position": executable,
                "shield_reason": decision.reason,
                "shield_reasons": list(decision.reasons),
                "shield_intervened": decision.intervened,
                "shield_intervention_rate": self.shield_state.intervention_rate,
                "fill_status": str(result.status),
                "filled_qty": result.filled_qty,
                "exec_price": result.exec_price,
                "fee": result.fee,
                "funding_cost": funding_cost,
                "slippage_bps": result.slippage_bps,
                "participation": result.participation,
                "net_log_return": breakdown.net_log_return,
                # Public price move over the bar just traded. Exposed so a wrapper
                # can price a *hypothetical* position (e.g. the unmodified
                # archetype's) without inventing an unobservable quantity.
                "mark_log_return": float(
                    np.log(float(self.data.close[next_t]) / float(self.data.close[t]))
                ),
                "reward_penalty": breakdown.total_penalty,
                "turnover_frac": turnover_frac,
                "liquidated": liquidated,
                "bankrupt": bankrupt,
            }
        )
        return self._observation(), float(breakdown.reward), terminated, truncated, info

    # -- helpers ----------------------------------------------------------- #
    def _force_flatten(self, index: int) -> None:
        """Liquidate at the bar close with a full taker cost. No pretending."""
        if self.ledger.qty == 0.0:
            return
        qty = -self.ledger.qty
        price = float(self.data.close[index])
        side = 1.0 if qty > 0 else -1.0
        hs = float(self.sim.half_spread[index])
        exec_price = price * (1.0 + side * hs)
        fee = abs(qty) * exec_price * self.sim.blended_fee_rate
        self.ledger.apply_trade(qty, exec_price, fee)

    def _observation(self) -> dict[str, np.ndarray]:
        market = self.scaler.transform(self.features.window(self._t)).astype(np.float32)
        turnover_recent = float(np.sum(self._turnover_window)) if self._turnover_window else 0.0
        steps_left = max(
            0, min(self.end_index - 1, self._episode_start + self.cfg.max_episode_bars) - self._t
        )
        risk_left = max(0.0, 1.0 - self.ledger.drawdown / max(self.shield.cfg.max_drawdown, _EPS))
        pf = portfolio_features(
            target_position=self._target_position,
            filled_position=self.ledger.position_frac,
            cash=self.ledger.cash,
            equity=self.ledger.equity,
            initial_equity=self.cfg.initial_cash,
            unrealized_pnl=self.ledger.unrealized_pnl,
            drawdown=self.ledger.drawdown,
            turnover_recent=turnover_recent,
            holding_bars=self._holding_bars,
            horizon=self.horizon_hint,
            steps_left=steps_left,
            risk_budget_left=risk_left,
            max_leverage=self.cfg.leverage,
        ).astype(np.float32)
        return {"market": market, "portfolio": pf}

    def _info_base(self) -> dict[str, Any]:
        return {
            "index": self._t,
            "timestamp": self.data.ts[self._t],
            "equity": self.ledger.equity,
            "position": self.ledger.position_frac,
            "cash": self.ledger.cash,
            "qty": self.ledger.qty,
            "drawdown": self.ledger.drawdown,
            "n_trades": self.ledger.n_trades,
        }

    # -- reporting --------------------------------------------------------- #
    def episode_summary(self) -> dict[str, Any]:
        """Unshaped economics for the evaluation stage."""
        self.ledger.reconcile()
        eq = np.asarray(self.stats.equity_curve, dtype=np.float64)
        return {
            "n_steps": len(self.stats.net_log_returns),
            "net_log_returns": np.asarray(self.stats.net_log_returns, dtype=np.float64),
            "equity_curve": eq,
            "positions": np.asarray(self.stats.positions, dtype=np.float64),
            "proposed_positions": np.asarray(self.stats.proposed_positions, dtype=np.float64),
            "rewards": np.asarray(self.stats.rewards, dtype=np.float64),
            "final_equity": float(eq[-1]) if eq.size else self.cfg.initial_cash,
            "fees": self.stats.fees,
            "funding": self.stats.funding,
            "execution_cost": self.stats.execution_cost,
            "turnover_notional": self.stats.turnover_notional,
            "n_trades": self.stats.n_trades,
            "n_partial_fills": self.stats.n_partial_fills,
            "n_rejected": self.stats.n_rejected,
            "n_liquidations": self.stats.n_liquidations,
            "bankrupt": self.stats.bankrupt,
            "shield_intervention_rate": self.shield_state.intervention_rate,
            "shield_reason_counts": dict(self.shield_state.reason_counts),
            "realized_pnl": self.ledger.cum_realized_pnl,
            "gross_pnl": self.ledger.cum_market_pnl,
        }

    def action_index(self, position: float) -> int:
        """Index of the discrete action realising ``position``. Raises if absent."""
        for i, p in enumerate(self.positions):
            if abs(p - position) < 1e-12:
                return i
        raise ValueError(f"position {position} is not in the action grid {self.positions}")
