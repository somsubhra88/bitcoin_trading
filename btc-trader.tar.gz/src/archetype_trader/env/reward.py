"""Reward shaping, kept separate from the unshaped economics.

:class:`RewardBreakdown` always carries ``net_log_return`` — the realised, fully
costed log-equity change with **no** shaping applied. Every metric in the
evaluation stage is computed from that field, so tuning the shaping terms cannot
make a bad strategy look good.
"""

from __future__ import annotations

import math
from dataclasses import dataclass

from archetype_trader.config import RewardConfig


@dataclass(frozen=True)
class RewardBreakdown:
    """Shaped reward and its components."""

    reward: float
    net_log_return: float
    turnover_penalty: float
    downside_penalty: float
    drawdown_penalty: float
    inventory_penalty: float
    vol_scale: float

    @property
    def total_penalty(self) -> float:
        return (
            self.turnover_penalty
            + self.downside_penalty
            + self.drawdown_penalty
            + self.inventory_penalty
        )


def compute_reward(
    cfg: RewardConfig,
    *,
    equity_before: float,
    equity_after: float,
    turnover_frac: float,
    drawdown: float,
    position_frac: float,
    realized_vol_per_bar: float,
    bars_per_year: int,
) -> RewardBreakdown:
    """Net log-equity change minus configured penalties.

    ``turnover_frac`` is traded notional divided by equity for this step.
    ``realized_vol_per_bar`` is the trailing per-bar return volatility, used only
    when ``vol_target_annual`` is set.
    """
    if equity_before <= 0 or equity_after <= 0:
        # Bankruptcy: a bounded, strongly negative signal. Using -inf or a raw
        # log of a non-positive equity would poison the advantage estimates.
        return RewardBreakdown(
            reward=-1.0 * cfg.scale,
            net_log_return=-1.0,
            turnover_penalty=0.0,
            downside_penalty=0.0,
            drawdown_penalty=0.0,
            inventory_penalty=0.0,
            vol_scale=1.0,
        )

    net = math.log(equity_after / equity_before)

    vol_scale = 1.0
    if cfg.vol_target_annual is not None:
        target_per_bar = cfg.vol_target_annual / math.sqrt(max(bars_per_year, 1))
        vol_scale = target_per_bar / max(realized_vol_per_bar, 1e-8)
        # Clamp so a quiet regime cannot multiply the reward without bound.
        vol_scale = min(max(vol_scale, 0.1), 10.0)

    shaped = net * vol_scale
    turn_pen = cfg.turnover_penalty * abs(turnover_frac)
    down_pen = cfg.downside_penalty * max(0.0, -net)
    dd_pen = cfg.drawdown_penalty * max(0.0, drawdown)
    inv_pen = cfg.inventory_penalty * abs(position_frac)
    reward = (shaped - turn_pen - down_pen - dd_pen - inv_pen) * cfg.scale
    return RewardBreakdown(
        reward=reward,
        net_log_return=net,
        turnover_penalty=turn_pen,
        downside_penalty=down_pen,
        drawdown_penalty=dd_pen,
        inventory_penalty=inv_pen,
        vol_scale=vol_scale,
    )
