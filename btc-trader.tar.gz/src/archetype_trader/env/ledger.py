"""Reconciled portfolio accounting.

One accounting identity covers both modes:

.. math:: E_t = \\text{cash}_t + q_t \\cdot m_t

where ``q`` is signed base quantity and ``m`` the mark price. Spot is this model
with ``q >= 0`` and ``cash >= 0``; a perpetual is the same model with cash
allowed to go negative (margin borrowing), which reproduces linear-perp PnL
exactly since :math:`dE = q\\,dm`.

Every equity change is attributed to exactly one of: market PnL, execution cost
(spread + slippage), fees, or funding. :meth:`Ledger.reconcile` re-derives
equity from those buckets and raises if it disagrees, so a broken cost model
cannot quietly inflate returns.
"""

from __future__ import annotations

from dataclasses import dataclass, field

_TOL = 1e-6


@dataclass(frozen=True)
class LedgerSnapshot:
    """Immutable view of the ledger at a bar close."""

    step: int
    cash: float
    qty: float
    mark: float
    equity: float
    position_frac: float
    peak_equity: float
    drawdown: float
    cum_market_pnl: float
    cum_execution_cost: float
    cum_fees: float
    cum_funding: float
    cum_turnover_notional: float
    cum_realized_pnl: float
    unrealized_pnl: float
    n_trades: int


@dataclass
class Ledger:
    """Mutable portfolio state with attributed cost accumulators."""

    initial_cash: float
    allow_negative_cash: bool
    cash: float = field(init=False)
    qty: float = 0.0
    mark: float = 0.0
    step: int = 0
    peak_equity: float = field(init=False)
    cum_market_pnl: float = 0.0
    cum_execution_cost: float = 0.0
    cum_fees: float = 0.0
    cum_funding: float = 0.0
    cum_turnover_notional: float = 0.0
    cum_realized_pnl: float = 0.0
    n_trades: int = 0
    #: Volume-weighted entry price of the open position; 0.0 when flat. Tracked
    #: only to report unrealised/realised PnL — the equity identity never uses it.
    avg_entry: float = 0.0

    def __post_init__(self) -> None:
        if self.initial_cash <= 0:
            raise ValueError(f"initial_cash must be positive, got {self.initial_cash}")
        self.cash = self.initial_cash
        self.peak_equity = self.initial_cash

    # -- state ------------------------------------------------------------- #
    @property
    def equity(self) -> float:
        return self.cash + self.qty * self.mark

    @property
    def position_frac(self) -> float:
        """Signed exposure as a fraction of equity (the RL "position")."""
        eq = self.equity
        if abs(eq) < 1e-12:
            return 0.0
        return self.qty * self.mark / eq

    @property
    def notional(self) -> float:
        return abs(self.qty) * self.mark

    @property
    def drawdown(self) -> float:
        if self.peak_equity <= 0:
            return 1.0
        return max(0.0, 1.0 - self.equity / self.peak_equity)

    @property
    def unrealized_pnl(self) -> float:
        """Mark-to-market PnL of the open position against its average entry."""
        if self.qty == 0.0 or self.avg_entry <= 0.0:
            return 0.0
        return self.qty * (self.mark - self.avg_entry)

    def set_mark(self, mark: float) -> float:
        """Re-mark inventory to ``mark``; returns the market PnL recognised."""
        if mark <= 0:
            raise ValueError(f"mark must be positive, got {mark}")
        pnl = self.qty * (mark - self.mark) if self.mark > 0 else 0.0
        self.mark = mark
        self.cum_market_pnl += pnl
        self.peak_equity = max(self.peak_equity, self.equity)
        return pnl

    def initialise_mark(self, mark: float) -> None:
        """Set the opening mark without booking PnL (start of an episode)."""
        if mark <= 0:
            raise ValueError(f"mark must be positive, got {mark}")
        self.mark = mark
        self.peak_equity = max(self.peak_equity, self.equity)

    # -- mutations --------------------------------------------------------- #
    def apply_trade(self, delta_qty: float, exec_price: float, fee: float) -> tuple[float, float]:
        """Book a fill of ``delta_qty`` at ``exec_price`` plus ``fee``.

        Returns ``(execution_cost, fee)``. Execution cost is the mark-relative
        slippage+spread the fill paid, which is non-negative for any fill priced
        against the trader (buy above mark, sell below).
        """
        if delta_qty == 0.0:
            return 0.0, 0.0
        if exec_price <= 0:
            raise ValueError(f"exec_price must be positive, got {exec_price}")
        if fee < 0:
            raise ValueError(f"fee must be non-negative, got {fee}")
        exec_cost = delta_qty * (exec_price - self.mark)
        self.cash -= delta_qty * exec_price + fee
        self._update_entry(delta_qty, exec_price)
        self.qty += delta_qty
        self.cum_execution_cost += exec_cost
        self.cum_fees += fee
        self.cum_turnover_notional += abs(delta_qty) * self.mark
        self.n_trades += 1
        if not self.allow_negative_cash and self.cash < -_TOL:
            raise AssertionError(
                f"spot ledger went cash-negative ({self.cash:.6f}); the sizing logic "
                "allowed an unfunded purchase"
            )
        self.peak_equity = max(self.peak_equity, self.equity)
        return exec_cost, fee

    def _update_entry(self, delta_qty: float, exec_price: float) -> None:
        """Maintain ``avg_entry`` and crystallise PnL on the closed portion."""
        qty = self.qty
        if qty == 0.0 or (qty > 0) == (delta_qty > 0):
            # Opening or adding: volume-weight the entry.
            total = abs(qty) + abs(delta_qty)
            self.avg_entry = (self.avg_entry * abs(qty) + exec_price * abs(delta_qty)) / total
            return
        closed = min(abs(delta_qty), abs(qty))
        direction = 1.0 if qty > 0 else -1.0
        self.cum_realized_pnl += direction * closed * (exec_price - self.avg_entry)
        if abs(delta_qty) > abs(qty):
            # Flipped through flat: the remainder opens a fresh position.
            self.avg_entry = exec_price
        elif abs(delta_qty) == abs(qty):
            self.avg_entry = 0.0

    def apply_funding(self, rate: float) -> float:
        """Charge funding on the current notional. Longs pay when ``rate > 0``."""
        cost = self.qty * self.mark * rate
        self.cash -= cost
        self.cum_funding += cost
        return cost

    # -- verification ------------------------------------------------------ #
    def reconcile(self, *, tol: float = 1e-6) -> None:
        """Assert ``equity == initial + pnl - costs``. Raises on mismatch."""
        expected = (
            self.initial_cash
            + self.cum_market_pnl
            - self.cum_execution_cost
            - self.cum_fees
            - self.cum_funding
        )
        err = abs(self.equity - expected)
        scale = max(1.0, abs(expected))
        if err / scale > tol:
            raise AssertionError(
                "ledger does not reconcile: "
                f"equity={self.equity:.10f} expected={expected:.10f} err={err:.3e} "
                f"(market_pnl={self.cum_market_pnl:.6f} exec_cost={self.cum_execution_cost:.6f} "
                f"fees={self.cum_fees:.6f} funding={self.cum_funding:.6f})"
            )

    def snapshot(self) -> LedgerSnapshot:
        return LedgerSnapshot(
            step=self.step,
            cash=self.cash,
            qty=self.qty,
            mark=self.mark,
            equity=self.equity,
            position_frac=self.position_frac,
            peak_equity=self.peak_equity,
            drawdown=self.drawdown,
            cum_market_pnl=self.cum_market_pnl,
            cum_execution_cost=self.cum_execution_cost,
            cum_fees=self.cum_fees,
            cum_funding=self.cum_funding,
            cum_turnover_notional=self.cum_turnover_notional,
            cum_realized_pnl=self.cum_realized_pnl,
            unrealized_pnl=self.unrealized_pnl,
            n_trades=self.n_trades,
        )
